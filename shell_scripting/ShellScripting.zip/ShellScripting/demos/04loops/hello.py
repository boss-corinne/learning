print 'Hello'
